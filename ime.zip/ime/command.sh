flex 1805092lex.l;
g++ lex.yy.c -o 1805092lex.out;
./1805092lex.out 1805092input.txt;
